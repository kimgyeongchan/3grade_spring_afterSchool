package com.example.demo.Controller;

import com.example.demo.Entity.Rfid;
import com.example.demo.Service.RfidCardService;
import org.json.JSONObject;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;


@Controller
public class RfidWebSocketController {

    @Autowired
    private RfidCardService rfidCardService;

    @MessageMapping("/ws5")   // 웹소켓에서 "/ws"로 수신한 메시지 처리
    public void receiveRfidData(String message) {
        // 메시지에서 UID를 추출해서 처리
        try {
            JSONObject jsonObject = new JSONObject(message);
            String uid = jsonObject.getString("uid");

            // JPA 엔티티에 저장
            Rfid rfidCard = new Rfid();
            rfidCard.setUid(uid);
            rfidCardService.saveRfidCardData(rfidCard);

            System.out.println("UID 저장됨: " + uid);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

