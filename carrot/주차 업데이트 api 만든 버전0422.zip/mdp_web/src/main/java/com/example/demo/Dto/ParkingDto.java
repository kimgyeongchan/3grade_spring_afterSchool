package com.example.demo.Dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ParkingDto {
    private Long id;
    private String car_number;
    private Boolean parking_status;
}
