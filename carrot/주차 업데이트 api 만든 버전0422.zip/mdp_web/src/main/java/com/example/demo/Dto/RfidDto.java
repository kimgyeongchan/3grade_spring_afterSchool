package com.example.demo.Dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RfidDto {
    private String uid;  // UID만 전송
}
