package com.example.demo.Dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TrafficDto {

    private int id;
    private int road_status;

}
