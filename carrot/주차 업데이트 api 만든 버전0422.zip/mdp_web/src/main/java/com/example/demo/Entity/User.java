package com.example.demo.Entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Entity  // 해당 클래스가 JPA의 엔티티(Entity)임을 명시
@Table(name = "users")  // 매핑할 테이블 이름 지정
@Getter  // Getter 메서드 자동 생성
@Setter  // Setter 메서드 자동 생성
@NoArgsConstructor  // 기본 생성자 자동 생성
public class User {
    @Id  // 기본 키(Primary Key) 지정
    @GeneratedValue(strategy = GenerationType.IDENTITY) // AUTO_INCREMENT
    private Long id;

    @Column(nullable = false, unique = true)  // id 필드 설정 (NOT NULL)
    private String email;

    @Column  // username 필드 설정 (NOT NULL)
    private String username;

    @Column(nullable = false)  // password 필드 설정 (NOT NULL)
    private String password;

    @Column(nullable = true)  // password 필드 설정 (NOT NULL)
    private int room;

    @Column(nullable = true)  // password 필드 설정 (NOT NULL)
    private String type;


}
