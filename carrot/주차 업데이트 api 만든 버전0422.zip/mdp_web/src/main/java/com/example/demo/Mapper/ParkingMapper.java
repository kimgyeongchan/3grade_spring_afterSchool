package com.example.demo.Mapper;

import com.example.demo.Dto.ParkingDto;
import com.example.demo.Entity.Parking;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface ParkingMapper {

    @Update("""
            update parking
            set parking_status = #{parking_status}
            where id = #{id};
            """)
    void ParkingStatusUpdate(ParkingDto parkingDto);
}
