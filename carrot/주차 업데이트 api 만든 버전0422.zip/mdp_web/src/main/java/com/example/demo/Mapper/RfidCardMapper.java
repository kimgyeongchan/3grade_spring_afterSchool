package com.example.demo.Mapper;

import com.example.demo.Entity.Rfid;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface RfidCardMapper {

    @Update("""
            UPDATE rfid
            SET uid = #{uid}
            WHERE id = 1;
            """)
    void RfidUpdate(Rfid rfidCard);
}
