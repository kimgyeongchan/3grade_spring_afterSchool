//package com.example.demo.Mapper;
//
//import com.example.demo.Dto.TrafficDto;
//import org.apache.ibatis.annotations.Insert;
//import org.apache.ibatis.annotations.Mapper;
//
//@Mapper
//public interface TrafficMapper {
//
//    @Insert("""
//            insert traffic_detection (road_status, create_dt) values (#{road_status},now());
//            """)
//    void TrafficSave (TrafficDto trafficDto);
//}
