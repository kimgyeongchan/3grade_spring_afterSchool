package com.example.demo.Service;


import com.example.demo.Dto.ParkingDto;

import java.util.Map;

public interface ParkingService {
    Map<String, Boolean> updateParkingStatus(Long id, ParkingDto parkingDto);
}
