package com.example.demo.Service;

import com.example.demo.Dto.ParkingDto;
import com.example.demo.Mapper.ParkingMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ParkingServiceImpl implements ParkingService{
    private final ParkingMapper parkingMapper;

    @Override
    public Map<String, Boolean> updateParkingStatus(Long id, ParkingDto parkingDto) {
        parkingDto.setId(id);
        parkingMapper.ParkingStatusUpdate(parkingDto);

        Map<String, Boolean> result = new HashMap<>();
        result.put("parking_status", parkingDto.getParking_status());
        return result;
    }
}
