package com.example.demo.Service;

import com.example.demo.Entity.Rfid;
import com.example.demo.Mapper.RfidCardMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class RfidCardService {

    private final RfidCardMapper rfidCardMapper;

    public void saveRfidCardData(Rfid rfidCard) {
        rfidCardMapper.RfidUpdate(rfidCard);
    }
}
