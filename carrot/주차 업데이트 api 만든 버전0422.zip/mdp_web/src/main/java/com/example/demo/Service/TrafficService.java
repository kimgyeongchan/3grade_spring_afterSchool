//package com.example.demo.Service;
//
//import com.example.demo.Dto.TrafficDto;
//import java.util.Map;
//
//public interface TrafficService {
//    Map<String, String> saveTraffic(TrafficDto trafficDto);
//}
