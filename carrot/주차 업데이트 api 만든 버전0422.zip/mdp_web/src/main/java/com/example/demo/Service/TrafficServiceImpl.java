//package com.example.demo.Service;
//
//import com.example.demo.Dto.TrafficDto;
//import com.example.demo.Mapper.TrafficMapper;
//import lombok.RequiredArgsConstructor;
//import org.springframework.stereotype.Service;
//
//import java.util.Map;
//
//@Service
//@RequiredArgsConstructor
//public class TrafficServiceImpl implements TrafficService{
//    private final TrafficMapper trafficMapper;
//
//    @Override
//    public Map<String, String> saveTraffic(TrafficDto trafficDto) {
//        trafficMapper.TrafficSave(trafficDto);
//        return null;
//    }
//}
