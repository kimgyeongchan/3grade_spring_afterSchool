package com.example.demo.Service;

import com.example.demo.Dto.UserDto;
import com.example.demo.Entity.User;
import com.example.demo.Mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class UserService {
    private final UserMapper userMapper;

    public List<User> findUserAll() {
        return userMapper.findAll();
    }

    public User getUserById(int id) {
        return userMapper.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    public Map<String, String> signup(UserDto dto) {
        if (userMapper.findByEmail(dto.getEmail()).isPresent()) {
            throw new IllegalArgumentException("이미 사용 중인 이메일입니다.");
        }

        User user = new User();
        user.setEmail(dto.getEmail());
        user.setUsername(dto.getUsername());
        user.setPassword(dto.getPassword());
        user.setRoom(dto.getRoom());
        user.setType(dto.getType());

        userMapper.insert(user);

        Map<String, String> result = new HashMap<>();
        result.put("type", "signup");
        result.put("success", "true");
        return result;
    }

    public Map<String, String> login(UserDto dto) {
        Optional<User> userOptional = userMapper.findByEmail(dto.getEmail());

        if (userOptional.isEmpty() || !userOptional.get().getPassword().equals(dto.getPassword())) {
            throw new IllegalArgumentException("이메일 또는 비밀번호가 올바르지 않습니다.");
        }

        Map<String, String> result = new HashMap<>();
        result.put("type", "login");
        result.put("success", "true");
        return result;
    }
}

