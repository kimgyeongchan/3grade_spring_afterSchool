package com.example.demo.config.handler;

import com.example.demo.Service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import org.springframework.stereotype.Component;
import com.example.demo.Dto.UserDto;

import java.util.HashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor //생성자 의존성
public class MyWebSocketHandler extends TextWebSocketHandler {

    private final UserService userService;
    //이거가 거시기 컨트롤러에 user 정보 보내기 위해 객체 생성
    ObjectMapper mapper = new ObjectMapper();

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        try {
            UserDto dto = mapper.readValue(message.getPayload(), UserDto.class);
            Map<String, String> response = new HashMap<>();

            switch (dto.getType()) {
                case "signup":
                    response = userService.signup(dto);
                    break;
                case "login":
                    response = userService.login(dto);
                    break;
                default:
                    response.put("type", "error");
                    response.put("success", "false");
                    response.put("message", "알 수 없는 요청입니다.");
                    break;
            }

            String json = mapper.writeValueAsString(response);
            session.sendMessage(new TextMessage(json));

        } catch (IllegalArgumentException e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("type", "error");
            errorResponse.put("success", "false");
            errorResponse.put("message", e.getMessage());

            String json = mapper.writeValueAsString(errorResponse);
            session.sendMessage(new TextMessage(json));
        }
    }
}
