package com.example.demo.config.handler;

import com.example.demo.Dto.ParkingDto;
import com.example.demo.Dto.RfidDto;
import com.example.demo.Entity.Parking;
import com.example.demo.Entity.Rfid;
import com.example.demo.Service.ParkingService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class ParkingWebSorketHandler extends TextWebSocketHandler {
    private final ParkingService parkingService;

    @Override
    public void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        try {
            //json으로 받은 메세지를 객체로 변환해줌(꺼내줌)
            String receivedMessage = (message.getPayload());
            //객체에 있는 값을 ParkingDto에 전달해주기 위해 함수를 사용 할 수 있도록 객체 생성
            ObjectMapper mapper = new ObjectMapper();
            //readValue 함수를 사용해 ParkingDto에 값을 넣어줌
            ParkingDto parkingDto = mapper.readValue(receivedMessage, ParkingDto.class);
            //엔티티 객체 사용하기 위해 생성
            Parking parking = new Parking();
            //dto로 값을 가져와서 엔티티에 넣어줌
            parking.setId(parkingDto.getId());
            //json으로 보내기 위해 객체 생성
            Map<String, Boolean> response = new HashMap<>();

            response = parkingService.updateParkingStatus(parkingDto.getId(), parkingDto);
            //json으로 보내기 위한 거시기 이거 뭐냐
            String json = mapper.writeValueAsString(response);
            //드디어 서비스에 엔티티로 id 값을 전해줌
            session.sendMessage(new TextMessage("차량 상태 업데이트 성공:"+json));
            parkingService.updateParkingStatus(parking.getId(), parkingDto);
        } catch (Exception e) {
            System.out.println("예외임");
        }
    }

}
