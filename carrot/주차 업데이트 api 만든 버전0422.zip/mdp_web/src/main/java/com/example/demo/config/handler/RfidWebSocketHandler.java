package com.example.demo.config.handler;

import com.example.demo.Dto.RfidDto;
import com.example.demo.Entity.Rfid;
import com.example.demo.Service.RfidCardService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class RfidWebSocketHandler extends TextWebSocketHandler{

    private final RfidCardService rfidCardService;

    @Override
    public void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        try {
            String receivedMessage = message.getPayload();
            // 메시지를 파싱하여 RfidDto 객체로 변환
            ObjectMapper mapper = new ObjectMapper();

            RfidDto dto = mapper.readValue(receivedMessage, RfidDto.class);
            // 받은 UID 값을 기반으로 데이터를 저장
            Rfid rfid = new Rfid();
            rfid.setUid(dto.getUid());
            rfidCardService.saveRfidCardData(rfid); // 서비스에서 데이터베이스 저장

            // 클라이언트에게 응답 메시지 보내기
            session.sendMessage(new TextMessage("RFID data update: " + dto.getUid()));
        } catch (Exception e) {
            session.sendMessage(new TextMessage("Error: " + e.getMessage()));
        }
    }
}

