//package com.example.demo.config.handler;
//
//
//import com.example.demo.Dto.TrafficDto;
//import com.example.demo.Service.TrafficService;
//import com.example.demo.Service.TrafficServiceImpl;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import lombok.RequiredArgsConstructor;
//import org.springframework.stereotype.Component;
//import org.springframework.web.socket.TextMessage;
//import org.springframework.web.socket.WebSocketSession;
//import org.springframework.web.socket.handler.TextWebSocketHandler;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@Component
//@RequiredArgsConstructor
//public class TrafficWebSorketHandler extends TextWebSocketHandler {
//    private final TrafficServiceImpl trafficServiceimpl;
//
//    @Override
//    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
//        try {
//            String payload = message.getPayload();  // 클라이언트가 보낸 JSON 문자열
//            ObjectMapper mapper = new ObjectMapper();
//            TrafficDto dto = mapper.readValue(payload, TrafficDto.class);  // JSON → DTO
//            Map<String, String> response = new HashMap<>();
//
//            response = trafficServiceimpl.saveTraffic(dto);
//
//            String json = mapper.writeValueAsString(response);
//            session.sendMessage(new TextMessage(json));
//        } catch (Exception e) {
//            e.printStackTrace(); // 디버깅에 도움됨
//        }
//    }
//
//}
