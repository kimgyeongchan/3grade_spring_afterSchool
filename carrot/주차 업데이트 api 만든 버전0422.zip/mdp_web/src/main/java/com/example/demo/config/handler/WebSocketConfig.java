package com.example.demo.config.handler;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@EnableWebSocket
@RequiredArgsConstructor
public class WebSocketConfig implements WebSocketConfigurer {

    private final MyWebSocketHandler myWebSocketHandler;
    private final RfidWebSocketHandler rfidWebSocketHandler;
//    private final TrafficWebSorketHandler trafficWebSorketHandler;
    private final ParkingWebSorketHandler parkingWebSorketHandler;

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry.addHandler(myWebSocketHandler, "/ws")
                .setAllowedOrigins("*");

        registry.addHandler(rfidWebSocketHandler, "/ws5/rfid")
                .setAllowedOrigins("*");

        registry.addHandler(parkingWebSorketHandler, "ws/parking")
                .setAllowedOrigins("*");

//        registry.addHandler(trafficWebSorketHandler, "/ws/traffic")
//                .setAllowedOrigins("*");
    }


}
